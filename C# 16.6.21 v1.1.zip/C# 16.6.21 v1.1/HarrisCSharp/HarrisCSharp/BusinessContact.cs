﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HarrisCSharp
{
    public class BusinessContact : Contact
    {
        public string ContactBusinessTel { get; set; }
    }
}
