﻿namespace AzmanSys
{
    partial class NewContactForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbContactID = new System.Windows.Forms.TextBox();
            this.tbFName = new System.Windows.Forms.TextBox();
            this.tbLName = new System.Windows.Forms.TextBox();
            this.tbHomeTel = new System.Windows.Forms.TextBox();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.logintitle = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tbContactType = new System.Windows.Forms.TextBox();
            this.tbBusinessTel = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbCity = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbPostcode = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbAddressLine2 = new System.Windows.Forms.TextBox();
            this.tbAddressLine1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnAdd.Location = new System.Drawing.Point(245, 415);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(148, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Contact ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(109, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Contact First Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(108, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Contact Last Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(77, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Contact Home Telephone:";
            // 
            // tbContactID
            // 
            this.tbContactID.Enabled = false;
            this.tbContactID.Location = new System.Drawing.Point(215, 104);
            this.tbContactID.Name = "tbContactID";
            this.tbContactID.ReadOnly = true;
            this.tbContactID.Size = new System.Drawing.Size(170, 20);
            this.tbContactID.TabIndex = 8;
            // 
            // tbFName
            // 
            this.tbFName.Location = new System.Drawing.Point(215, 156);
            this.tbFName.Name = "tbFName";
            this.tbFName.Size = new System.Drawing.Size(170, 20);
            this.tbFName.TabIndex = 9;
            // 
            // tbLName
            // 
            this.tbLName.Location = new System.Drawing.Point(215, 182);
            this.tbLName.Name = "tbLName";
            this.tbLName.Size = new System.Drawing.Size(170, 20);
            this.tbLName.TabIndex = 10;
            // 
            // tbHomeTel
            // 
            this.tbHomeTel.Location = new System.Drawing.Point(215, 208);
            this.tbHomeTel.Name = "tbHomeTel";
            this.tbHomeTel.Size = new System.Drawing.Size(170, 20);
            this.tbHomeTel.TabIndex = 11;
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnMainMenu.Location = new System.Drawing.Point(402, 19);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(82, 22);
            this.btnMainMenu.TabIndex = 35;
            this.btnMainMenu.Text = "Back";
            this.btnMainMenu.UseVisualStyleBackColor = false;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(134, 267);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 36;
            this.label5.Text = "Contact Email:";
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(215, 260);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(170, 20);
            this.tbEmail.TabIndex = 37;
            // 
            // logintitle
            // 
            this.logintitle.AutoSize = true;
            this.logintitle.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logintitle.ForeColor = System.Drawing.Color.Blue;
            this.logintitle.Location = new System.Drawing.Point(58, 12);
            this.logintitle.Name = "logintitle";
            this.logintitle.Size = new System.Drawing.Size(327, 29);
            this.logintitle.TabIndex = 39;
            this.logintitle.Text = "Harris and Sons Consulting LTD.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(125, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(195, 23);
            this.label6.TabIndex = 40;
            this.label6.Text = "Add New Contact Details";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(41, 133);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 13);
            this.label7.TabIndex = 41;
            this.label7.Text = "Contact Type: Personal/Business:";
            // 
            // tbContactType
            // 
            this.tbContactType.Location = new System.Drawing.Point(215, 130);
            this.tbContactType.Name = "tbContactType";
            this.tbContactType.Size = new System.Drawing.Size(170, 20);
            this.tbContactType.TabIndex = 42;
            // 
            // tbBusinessTel
            // 
            this.tbBusinessTel.Location = new System.Drawing.Point(215, 234);
            this.tbBusinessTel.Name = "tbBusinessTel";
            this.tbBusinessTel.Size = new System.Drawing.Size(170, 20);
            this.tbBusinessTel.TabIndex = 44;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(63, 237);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(146, 13);
            this.label8.TabIndex = 43;
            this.label8.Text = "Contact Business Telephone:";
            // 
            // tbCity
            // 
            this.tbCity.Location = new System.Drawing.Point(215, 358);
            this.tbCity.Name = "tbCity";
            this.tbCity.Size = new System.Drawing.Size(170, 20);
            this.tbCity.TabIndex = 52;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(142, 361);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 13);
            this.label9.TabIndex = 51;
            this.label9.Text = "Contact City:";
            // 
            // tbPostcode
            // 
            this.tbPostcode.Location = new System.Drawing.Point(215, 384);
            this.tbPostcode.Name = "tbPostcode";
            this.tbPostcode.Size = new System.Drawing.Size(170, 20);
            this.tbPostcode.TabIndex = 50;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(114, 391);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 13);
            this.label10.TabIndex = 49;
            this.label10.Text = "Contact Postcode:";
            // 
            // tbAddressLine2
            // 
            this.tbAddressLine2.Location = new System.Drawing.Point(215, 332);
            this.tbAddressLine2.Name = "tbAddressLine2";
            this.tbAddressLine2.Size = new System.Drawing.Size(170, 20);
            this.tbAddressLine2.TabIndex = 48;
            // 
            // tbAddressLine1
            // 
            this.tbAddressLine1.Location = new System.Drawing.Point(215, 306);
            this.tbAddressLine1.Name = "tbAddressLine1";
            this.tbAddressLine1.Size = new System.Drawing.Size(170, 20);
            this.tbAddressLine1.TabIndex = 47;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(89, 335);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 13);
            this.label11.TabIndex = 46;
            this.label11.Text = "Contact Address Line 2:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(89, 309);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 13);
            this.label12.TabIndex = 45;
            this.label12.Text = "Contact Address Line 1:";
            // 
            // NewContactForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(497, 450);
            this.Controls.Add(this.tbCity);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.tbPostcode);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.tbAddressLine2);
            this.Controls.Add(this.tbAddressLine1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.tbBusinessTel);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tbContactType);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.logintitle);
            this.Controls.Add(this.tbEmail);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.tbHomeTel);
            this.Controls.Add(this.tbLName);
            this.Controls.Add(this.tbFName);
            this.Controls.Add(this.tbContactID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAdd);
            this.Name = "NewContactForm";
            this.Text = "NewContact";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbContactID;
        private System.Windows.Forms.TextBox tbFName;
        private System.Windows.Forms.TextBox tbLName;
        private System.Windows.Forms.TextBox tbHomeTel;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.Label logintitle;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbContactType;
        private System.Windows.Forms.TextBox tbBusinessTel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbCity;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbPostcode;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbAddressLine2;
        private System.Windows.Forms.TextBox tbAddressLine1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}