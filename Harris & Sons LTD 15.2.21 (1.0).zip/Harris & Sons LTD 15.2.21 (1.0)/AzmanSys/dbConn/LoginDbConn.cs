﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AzmanSys
{
    class LoginDbConn : dbConn
    {





        public void ValidateLogin(string Username, string Password)
        {
           MySqlCommand comm = conn.CreateCommand();
                comm.CommandText = "SELECT*FROM Login where Username=@Username AND Password=@Password";
                comm.Parameters.AddWithValue("@Username", Username);
                comm.Parameters.AddWithValue("@Password", Password);
                MessageBox.Show("Login sucessful");
                comm.ExecuteNonQuery(); 
                connClose();
        }
    }
}
