﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace AzmanSys
{
    class ContactDbConn: dbConn
    {
        public void insertContact(string ContactType, string ContactFName, string ContactLName, int ContactHomeTel, int ContactBusinessTel, string ContactEmail, string ContactAddr1, string ContactAddr2, string ContactCity, string ContactPostcode)
        {
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = "UPDATE `Contacts` SET 'ContactType'=@ContactType, 'ContactFName'=@ContactFName, 'ContactLName'=@ContactLName, 'ContactHomeTel'=@ContactHomeTel, 'ContactBusinessTel'=@ContactBusinessTel, 'ContactEmail'=@ContactEmail, 'ContactAddr1'=@ContactAddr1, 'ContactAddr2'=@ContactAddr2, 'ContactCity'=@ContactCity, 'ContactPostcode'=@ContactPostcode WHERE ContactID=@ContactID";
            comm.Parameters.AddWithValue("@ContactType", ContactType);
            comm.Parameters.AddWithValue("@ContactFName", ContactFName);
            comm.Parameters.AddWithValue("@ContactLName", ContactLName);
            comm.Parameters.AddWithValue("@ContactHomeTel", ContactHomeTel);
            comm.Parameters.AddWithValue("@ContactBusinessTel", ContactBusinessTel);
            comm.Parameters.AddWithValue("@ContactEmail", ContactEmail);
            comm.Parameters.AddWithValue("@ContactAddr1", ContactAddr1);
            comm.Parameters.AddWithValue("@ContactAddr2", ContactAddr2);
            comm.Parameters.AddWithValue("@ContactCity", ContactCity);
            comm.Parameters.AddWithValue("@ContactPostcode", ContactPostcode);
            comm.ExecuteNonQuery();
            connClose();
        }

        internal void deleteContact(string text)
        {
            throw new NotImplementedException();
        }

        //Inserts the details of a new contact into the Database table "Contacts" by adding contact details into the table.

        public void updateContact(int ContactID, string ContactType, string ContactFName, string ContactLName, int ContactHomeTel, int ContactBusinessTel, string ContactEmail, string ContactAddr1, string ContactAddr2, string ContactCity, string ContactPostcode)
        {
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = "UPDATE `Contacts` SET 'ContactType'=@ContactType, 'ContactFName'=@ContactFName, 'ContactLName'=@ContactLName, 'ContactHomeTel'=@ContactHomeTel, 'ContactBusinessTel'=@ContactBusinessTel, 'ContactEmail'=@ContactEmail, 'ContactAddr1'=@ContactAddr1, 'ContactAddr2'=@ContactAddr2, 'ContactCity'=@ContactCity, 'ContactPostcode'=@ContactPostcode WHERE ContactID=@ContactID";
            comm.Parameters.AddWithValue("@ContactID", ContactID);
            comm.Parameters.AddWithValue("@ContactType", ContactType);
            comm.Parameters.AddWithValue("@ContactFName", ContactFName);
            comm.Parameters.AddWithValue("@ContactLName", ContactLName);
            comm.Parameters.AddWithValue("@ContactHomeTel", ContactHomeTel);
            comm.Parameters.AddWithValue("@ContactBusinessTel", ContactBusinessTel);
            comm.Parameters.AddWithValue("@ContactEmail", ContactEmail);
            comm.Parameters.AddWithValue("@ContactAddr1", ContactAddr1);
            comm.Parameters.AddWithValue("@ContactAddr2", ContactAddr2);
            comm.Parameters.AddWithValue("@ContactCity", ContactCity);
            comm.Parameters.AddWithValue("@ContactPostcode", ContactPostcode);
            comm.ExecuteNonQuery();
            connClose();
        }

        internal void insertContact(string text1, string text2, string text3, string text4, string text5, string text6, string text7, string text8)
        {
            throw new NotImplementedException();
        }

        //Updates contact details in the Database by replacing the existing contact details with the new contact details.

        public void deleteContact(int ContactID)
        {
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = "DELETE FROM `Contacts` WHERE 'ContactID' = @ContactID";
            comm.Parameters.AddWithValue("@ContactID", ContactID);
            comm.ExecuteNonQuery();
            connClose();
        }
        //Deletes a contact by removing contact details from the database.
    }
}
