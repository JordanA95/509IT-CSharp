﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AzmanSys
{
    public partial class ContactsForm : Form
    {
        ContactDbConn mysqlConn;
        public ContactsForm()
        {
            InitializeComponent();
            mysqlConn = new ContactDbConn();
            mysqlConn.connect();
            if (mysqlConn.connOpen() == true)
            {
                dataGridViewContacts.DataSource = mysqlConn.qry("SELECT * FROM `Contacts`").Tables[0];
            }
            mysqlConn.connClose();
        }
        //Connects to the MySQL Database table Contacts.
        private void btnAdd_Click(object sender, EventArgs e)
        {
            (new NewContactForm()).Show();
        }
        //Opens the 'new contact' form.

        private void btnUpdate_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                if (mysqlConn.connOpen() == true)
                {
                    //mysqlConn.deleteContact(tbContactID.Text);
                    dataGridViewContacts.DataSource = mysqlConn.qry("SELECT * FROM `Contacts`").Tables[0];
                }
                mysqlConn.connClose();
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            Close();
            (new LoginForm()).Show();
        }

        private void BookingsForm_Load(object sender, EventArgs e)
        {

        }

        private void printbookingsbtn_Click(object sender, EventArgs e)
        {
            
        }
        
        Bitmap memoryImage;

        private void CaptureScreen()
        {
            Graphics myGraphics = this.CreateGraphics();
            Size s = this.Size;
            memoryImage = new Bitmap(s.Width, s.Height, myGraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            memoryGraphics.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, s);
        }
        //Captures the screen to print the form.

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

        }

        private void printDocument1_PrintPage_1(object sender, PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(memoryImage, 0, 0);
        }

        private void Refreshbtn_Click(object sender, EventArgs e)
        {
            dataGridViewContacts.DataSource = mysqlConn.qry("SELECT * FROM `Contacts`").Tables[0];
        }
    }
}
