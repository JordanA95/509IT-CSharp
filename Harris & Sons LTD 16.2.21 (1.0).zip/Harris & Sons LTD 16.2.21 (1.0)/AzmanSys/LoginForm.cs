﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AzmanSys
{
    public partial class LoginForm : Form
    {
        LoginDbConn mysqlConn;
        public LoginForm()
        {
            InitializeComponent();
            mysqlConn = new LoginDbConn();
            mysqlConn.connect();
        }

        private void Signinbtn_Click(object sender, EventArgs e)
        {
            if (Usernametxb.Text =="")
            {
                MessageBox.Show("Please enter a valid username");
                Usernametxb.Focus();
            } else if(Passwordtxb.Text == "")
            {
                MessageBox.Show("Password Incorrect");
                Passwordtxb.Focus();
            }
            if (Usernametxb.Text != "" & Passwordtxb.Text != "") //!= is checking that the textbox is NOT empty
            {
                //Login check code goes here to check username and password are correct
                {
                    MessageBox.Show("Login Successful"); //Login successful message
                    Close();
                    (new ContactsForm()).Show();
                } //else
                {
                    MessageBox.Show("Incorrect Username or Password"); //Login unsuccessful message
                }

            }
        }

        private void Usernametxb_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
