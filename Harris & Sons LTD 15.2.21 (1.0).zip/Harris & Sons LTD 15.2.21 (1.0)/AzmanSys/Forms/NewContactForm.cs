﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AzmanSys
{
    public partial class NewContactForm : Form
    {
        ContactDbConn mysqlConn;
        public NewContactForm()
        {
            InitializeComponent();
            mysqlConn = new ContactDbConn();
            mysqlConn.connect();
            if (mysqlConn.connOpen() == true)
            mysqlConn.connClose();
        }
        //This is the code conecting the NewContctForm to the Database

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (tbContactType.Text == "")
            {
                MessageBox.Show("Please specify whether the contact is business or personal");
            }
            else if (tbFName.Text == "")
            {
                MessageBox.Show("Please enter the contact's first name");
            }
            else if (tbLName.Text == "")
            {
                MessageBox.Show("Please enter the contact's last name");
            }
            else if (tbEmail.Text == "")
            {
                MessageBox.Show("Please enter the contact's email");
            }
            else if (tbAddressLine1.Text == "")
            {
                MessageBox.Show("Please enter the first line of the contact's address");
            }
            else if (tbAddressLine2.Text == "")
            {
                MessageBox.Show("Please enter the second line of the contact's address");
            } 
            else if (tbCity.Text == "")
            {
                MessageBox.Show("Please enter the city of the contact's address");
            }
            else if (tbPostcode.Text == "")
            {
                MessageBox.Show("Please enter the contact's postcode");
            };
            if (tbFName.Text != "" & tbLName.Text != "" & tbHomeTel.Text != "" & tbEmail.Text !="") //!= is checking that the textboxes are NOT empty
                if (mysqlConn.connOpen() == true)
            {
            mysqlConn.insertContact(tbContactType.Text, tbFName.Text, tbBusinessTel.Text, tbEmail.Text, tbAddressLine1.Text, tbAddressLine2.Text, tbCity.Text, tbPostcode.Text);
            }
            mysqlConn.connClose();
            Close();
            (new ContactsForm()).Show();
        }
        //This is the code for adding a new contact to the Contacts table.
        
        
        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            Close();
            (new ContactsForm()).Show();
        }
        //This is the code for returning to the main menu by closing the CustomersForm and opening the MainForm.

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //This is the code for closing the whole application.

        private void btnMainMenu_Click_1(object sender, EventArgs e)
        {
            Close();
            (new ContactsForm()).Show();
        }
        //This is the code for returning to the ContactsForm.
        private void printcustomersbtn_Click(object sender, EventArgs e)
        {
            CaptureScreen();
            printDocument1.Print();
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
        }
        
        Bitmap memoryImage;

        private void CaptureScreen()
        {
            Graphics myGraphics = this.CreateGraphics();
            Size s = this.Size;
            memoryImage = new Bitmap(s.Width, s.Height, myGraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            memoryGraphics.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, s);
        }
        //This is the code for capturing what is on the screen/form for printing

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

        }

        private void printDocument1_PrintPage_1(object sender, PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(memoryImage, 0, 0);
        }
    }
}
