﻿namespace AzmanSys
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Signinbtn = new System.Windows.Forms.Button();
            this.Usernametxb = new System.Windows.Forms.TextBox();
            this.Passwordtxb = new System.Windows.Forms.TextBox();
            this.logintitle = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Signinbtn
            // 
            this.Signinbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Signinbtn.Location = new System.Drawing.Point(152, 192);
            this.Signinbtn.Name = "Signinbtn";
            this.Signinbtn.Size = new System.Drawing.Size(106, 51);
            this.Signinbtn.TabIndex = 0;
            this.Signinbtn.Text = "Log In";
            this.Signinbtn.UseVisualStyleBackColor = false;
            this.Signinbtn.Click += new System.EventHandler(this.Signinbtn_Click);
            // 
            // Usernametxb
            // 
            this.Usernametxb.Location = new System.Drawing.Point(141, 95);
            this.Usernametxb.Name = "Usernametxb";
            this.Usernametxb.Size = new System.Drawing.Size(182, 20);
            this.Usernametxb.TabIndex = 1;
            this.Usernametxb.Text = "\"Testuser\"";
            this.Usernametxb.TextChanged += new System.EventHandler(this.Usernametxb_TextChanged);
            // 
            // Passwordtxb
            // 
            this.Passwordtxb.Location = new System.Drawing.Point(141, 142);
            this.Passwordtxb.Name = "Passwordtxb";
            this.Passwordtxb.Size = new System.Drawing.Size(182, 20);
            this.Passwordtxb.TabIndex = 2;
            this.Passwordtxb.Text = "password";
            // 
            // logintitle
            // 
            this.logintitle.AutoSize = true;
            this.logintitle.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logintitle.ForeColor = System.Drawing.Color.Blue;
            this.logintitle.Location = new System.Drawing.Point(76, 9);
            this.logintitle.Name = "logintitle";
            this.logintitle.Size = new System.Drawing.Size(247, 23);
            this.logintitle.TabIndex = 3;
            this.logintitle.Text = "Harris and Sons Consulting LTD.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(77, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Username:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(79, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Password:";
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(365, 286);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.logintitle);
            this.Controls.Add(this.Passwordtxb);
            this.Controls.Add(this.Usernametxb);
            this.Controls.Add(this.Signinbtn);
            this.Name = "LoginForm";
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Signinbtn;
        private System.Windows.Forms.TextBox Usernametxb;
        private System.Windows.Forms.TextBox Passwordtxb;
        private System.Windows.Forms.Label logintitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}