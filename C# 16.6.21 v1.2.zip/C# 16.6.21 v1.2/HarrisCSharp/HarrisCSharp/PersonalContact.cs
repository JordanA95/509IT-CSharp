﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HarrisCSharp
{
    public class PersonalContact : Contact
    {
        public string ContactPersonalTel { get; set; }
    }
}
